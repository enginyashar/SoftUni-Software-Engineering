﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftUniKindergarten
{
    public class Kindergarten
    {
        public Kindergarten(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;

            Registry = new List<Child>();
        }

        public List<Child> Registry { get; set; }
        public string Name { get; set; }
        public int Capacity { get; set; }

        public bool AddChild(Child child)
        {
            if (Registry.Count >= Capacity)
            {
                return false;
            }

            Registry.Add(child);
            return true;
        }

        public bool RemoveChild(string childFullName)
        {
            Child childToRemove = Registry.FirstOrDefault(c => $"{c.FirstName} {c.LastName}" == childFullName);

            if (childToRemove == null)
            {
                return false;
            }

            return Registry.Remove(childToRemove);
        }
        public int ChildrenCount
        {
            get { return Registry.Count; }
        }

        public Child GetChild(string childFullName)
        {
            return Registry.FirstOrDefault(c => $"{c.FirstName} {c.LastName}" == childFullName);
        }

        public string RegistryReport()
        {
            StringBuilder print = new StringBuilder();

            print.AppendLine($"Registered children in {Name}:");

            foreach (var child in Registry.OrderByDescending(c => c.Age).ThenBy(c => c.LastName).ThenBy(c => c.FirstName).ToList())
            {
                print.AppendLine(child.ToString());
            }
            return print.ToString().Trim();
        }
    }
}
